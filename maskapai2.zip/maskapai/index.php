<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Maskapai Penerbangan</title>
<meta name="keywords" content="Perspective Template, free css template, download" />
<meta name="description" content="Perspective Template - Download free css template" />
<link href="templatemo_style.css" rel="stylesheet" type="text/css" />
</head>
<body>
<div id="templatemo_header_wrapper">
	<!--  Free Web Templates by TemplateMo.com  -->
	<div id="templatemo_header">
    	<div id="site_title">
        	<a href="#" target="_parent">
            <span>Maskapai Jumiaty </span>        </div>
  </div>

</div> <!-- end of header -->

<div id="templatemo_content_wrapper">

	<div id="templatemo_content">
	  <div id="templatemo_menu">
        	<div id="templatemo_menu_left"></div>
            <ul>
                <li><a href="index.php" class="current">Home</a></li>
                <li><a href="bandara.php" target="_parent">Bandara</a></li>
                <li><a href="pesawat.php" target="_parent">Maskapai</a></li>
                <li><a href="inde.php" target="_parent"> Tiket </a></li>
                <li><a href="Biodata.php" target="_parent">Menu Awal</a></li>
                <li><a href="Biodata.php" class="current">Biodata</a></li>
            </ul>    	
      </div> <!-- end of menu -->
	  <div id="content_column">
            <div class="post_section">
                <div class="header_01">Lion Air</div>
                <div class="post_info">Jan 24th in <a href="#" target="_parent">Web Template</a> by <a href="#" target="_parent">Jumiaty.com</a></div>
                
                <div class="post_content"><img src="images/lionair.jpg" alt="lionair" width="539" height="312" />Lion Air merupakan maskapai swasta terbesar Indonesia, berpusat di Jakarta. LionAir menjadi bagian populer karena keagresifanya, tetapi memiliki struktur harga yang fleksibel. Saat ini Lion Air memiliki 60 armada pesawat yang beroperasi (dengan perkiraan usia armada 6,8 tahun) dan 230 masih dalam pemesanan. Armada Lion Air melayani penerbangan 3300 seminggu untuk 36 tujuan - baik domestik dan internasional.
                  <div class="link_button">
                	<a href="#">Continue reading...</a> | <a href="#">Comments (256)</a></div>
              </div>	            
            </div>
            <div class="post_section">
                <div class="header_01">Garuda Indonesia</div>
                <div class="post_info">
                	Jan 24th in <a href="#" target="_parent">Web Template</a> by <a href="#" target="_parent">Jumiaty.com</a>
                </div>  
                <div class="post_content">
                	<img src="images/Garuda-Indonesia.jpg" alt="garuda" width="540" height="287" />Garuda Indonesia merupakan maskapai nasional Indonesia dan terbesar (pesawat 100+, 50 rute) di antara semua maskapai penerbangan yang beroperasi di negara tersebut. Perusahaan ini didirikan pada tahun 1949 dan sejak itu telah membangun reputasi untuk memberikan tarif moderat dan tingkat pelayanan yang lebih tinggi dibanding perusahaan penerbangan Indonesia lainnya. Konsep baru dari layanan (&quot;The Garuda Indonesia Experience&quot;) mencakup aspek budaya Indonesia, masakan dan perhotelan.
                	<p><a href="#">Continue reading...</a> | <a href="#">Comments (512)</a>				</p>
           	  </div>
            <div class="cleaner"></div>
        </div> <!-- end of content column -->
        
        </div> <!-- end of content column -->

        <div id="side_column_wrapper">
        <div id="side_column">
                
                <div class="section_w260">
                	<div class="ads_125_125 margin_right_10">
                    	<a href="#"><img src="images/templatemo_ads.jpg" alt="image" /></a>
                    </div>
                    <div class="ads_125_125">
                    	<a href="#"><img src="images/templatemo_ads.jpg" alt="image" /></a>
                    </div>
                    <div class="ads_125_125 margin_right_10">
                    	<a href="#"><img src="images/templatemo_ads.jpg" alt="image" /></a>
                    </div>
                    <div class="ads_125_125">
                    	<a href="#"><img src="images/templatemo_ads.jpg" alt="image" /></a>
                    </div>
                    
                    <div class="cleaner"></div>
                </div>
                
                <div class="section_w260">
		            <div class="header_02">Recent Posts</div>
                  <div class="recent_post">
                   	  <div class="header_04"><a href="#">Maskapai </a></div>
                    </div>
                    
                    <div class="recent_post">
                   	  <div class="header_04"><a href="#">Bandara</a></div>
                    </div>
                    
                    <div class="recent_post">
                      <div class="header_04"><a href="#"> Tiket </a></div>
                  </div>    
                </div>
                
                <div class="section_w260">
		            <div class="header_02"></div>
          </div> 
                     
        </div> <!-- end of side column -->
        </div>
        
        <div class="cleaner"></div>
  </div> <!-- end of content -->
    
     <div class="cleaner"></div>
</div> <!-- end of content wrapper -->

<div id="templatemo_footer_wrapper">
  <div id="templatemo_footer">
    
    	<div class="section_w180px">
        	<div class="header_03">Popular Posts</div>
        	<ul class="footer_menu_list">
            	<li></li>
            </ul>
        </div>
        
        <div class="section_w180px">
	        <div class="header_03">Recent Posts</div>
        	<ul class="footer_menu_list">
                <li></li>
            </ul>
        </div>
        
        <div class="section_w180px">
			<div class="header_03">Partners</div>        
        	<ul class="footer_menu_list">
            	<li></li>
            </ul>
        </div>
        
        <div class="section_w180px">
			<div class="header_03">Other Info.</div>        
        	<ul class="footer_menu_list"><li></li>               
            </ul>
        </div>
        
        <div class="section_w180px">
			<div class="header_03">XHTML/CSS Validators</div>        
        		<a href="http://validator.w3.org/check?uri=referer"><img style="border:0;width:88px;height:31px" src="http://www.w3.org/Icons/valid-xhtml10" alt="Valid XHTML 1.0 Transitional" width="88" height="31" vspace="8" border="0" /></a>
                <div class="margin_bottom_10"></div>
    			<a href="http://jigsaw.w3.org/css-validator/check/referer"><img style="border:0;width:88px;height:31px"  src="http://jigsaw.w3.org/css-validator/images/vcss-blue" alt="Valid CSS!" vspace="8" border="0" /></a>
        </div>
        <!--  Free CSS Template provided by www.TemplateMo.com  -->
    	<div class="margin_bottom_20"></div> 
      Copyright © 2048 <a href="#">JUMIATY.COM</a> | 
	  <a href="http://www.iwebsitetemplate.com" target="_parent">Website Templates</a> by <a href="#" target="_parent">Free CSS Templates</a>    </div> 
    <!-- end of footer -->
</div>
<div align=center>This template  downloaded form <a href='http://all-free-download.com/free-website-templates/'>free website templates</a></div></body>
</html>