<!DOCTYPE html>

<html>
<head>
<meta name="description" content="Biodata"/>
<meta name="Keywords" content="Biodata"/>
<meta name="authors" content="Jumiaty Rahmi"/>
<meta charset="UTF-8"/>
<title>Biodata</title>
<link rel="stylesheet" href="styleku.css"/>
</head>
<body>
<form action="#" style="width: 1000px"class="posisi";>
<fieldset class="h"/>
<table style="width: 980px;">
<tr>
<td rowspan="15" width="250px">
<img src="https://docs.google.com/uc?id=1o2lA-jxsLw4gluhmaF8EH6ncp0zHcd9x" style="width: 500px";height:400px;width:500px"></iframe>
</td>
</tr>
<tr>
<td><b>Nama Lengkap</b></td>
<td>:</td>
<td>Jumiaty Rahmi</td>
</tr>
<tr>
<td><b>Nama Panggilan</b></td>
<td>:</td>
<td>Rahmi</td>
</tr>
<tr>
<td><b>Tempat, Tanggal Lahir</b></td>
<td>:</td>
<td>Bengkalis, 20 Januari 1995</td>
</tr>
<tr>
<td><b>Umur</b></td>
<td>:</td>
<td>24 Tahun</td>
</tr>
<tr>
<td><b>Jenis Kelamin</b></td>
<td>:</td>
<td>Perempuan</td>
</tr>
<tr>
<td><b>Gol. Darah</b></td>
<td>:</td>
<td>O</td>
</tr>
<tr>
<td><b>Agama</b></td>
<td>:</td>
<td>Islam</td>
</tr>
<tr>
<td><b>Alamat</b></td>
<td>:</td>
<td>JL Spoor Dalam 4 No 54A RT 009 RW 002 Kemayoran, Jakarta Pusat 10610 
Kec. Kemayoran, Kota/Kab. Jakarta Pusat DKI Jakarta</td>
</tr>
<tr>
<td><b>Status</b></td>
<td>:</td>
<td>Belum Menikah</td>
</tr>
<tr>
<td><b>Pekerjaan</b></td>
<td>:</td>
<td>Swasta</td>
</tr>
<tr>
<td><b>Kewarganegaraan</b></td>
<td>:</td>
<td>Indonesia</td>
</tr>
<tr>
<td><b>Riwayat</b></td>
<td>:</td>
<td colspan="1" align="left">
Ingin Tahu Riwayatku ? <a href="Detail.php"style="text-decoration: none;" target="_parent"><input
type="button"value="Cari tahu ? "/></a>
<a href="index.php" style="text-decoration: none;"</a><input type="button" onclick="history.back()" value="Menu Maskapai"/>
</td>
</tr>
</table>
</fieldset>
</form>
</body>
</html>