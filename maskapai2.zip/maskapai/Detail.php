<!DOCTYPE html>
<style>
table,tr,td{
font-family: century gothic;
color: black ;
border: 1px solid aqua;
padding: 5px;
background-color: white;
}
.posisi{
position: absolute;
margin-left: auto;
margin-right: auto;
margin-bottom: auto;
margin-top: auto;
left: 160px;
right: 0;
top: 60px;
bottom: 0;
}
body{
background-image: url('Jumiatyy.jpg');
background-repeat: no-repeat;
background-size: 1480px auto;
background-attachment: fixed;
}
</style>
<html>
<head>
<meta name="description" content="Biodata"/>
<meta name="Keywords" content="Biodata"/>
<meta name="authors" content="Jumiaty Rahmi"/>
<meta charset="UTF-8"/>
<title>Biodata</title>
<link rel="stylesheet" href="orapopo.css"/>
</head>
<body>
<form action="#" style="width: 1000px"class="posisi";>
<table style="width: 950px;">
<tr>
<td colspan="4" style="text-align: center; background-color: Green;color: orange"><b>Riwayat Jenjang Pendidikan Formal</b></td>
</tr>
<tr>
<td style="text-align: center">Jenjang Pendidikan</td>
<td style="text-align: center">Keterangan</td>
<td style="text-align: center">Bidang Jurusan</td>
<td style="text-align: center">Tahun</td>
</tr>
<tr>
<td>SEKOLAH DASAR</td>
<td>SD Islam Budi Mulia Padang, Sumatera Barat</td>
<td>Tidak ada</td>
<td>2001 s.d 2008</td>
</tr>
<tr>
<td>SEKOLAH MENENGAH PERTAMA</td>
<td>Sekolah Menengah Pertama Negeri 10 Padang, Sumatera Barat</td>
<td>Tidak ada</td>
<td>2008 s.d 2011</td>
</tr>
<tr>
<td>SEKOLAH MENENGAH KEJURUAN</td>
<td>Sekolah Menengah Kejuruan Negeri 2 Padang, Sumatera Barat</td>
<td>Rekayasa Perangkat Lunak</td>
<td>2011 s.d 2014 </td>
</tr>
<tr>
<td>DIPLOMA 3</td>
<td>Politeknik Negeri Padang, Sumatera Barat </td>
<td>Teknik Komputer</td>
<td>2014 s.d 2018</td>
</tr>
</table>
<br>
<table style="width: 750px;">
<tr>
<td colspan="4" style="text-align: center; background-color: Green;color: orange"><b>Informasi Umum</b></td>
</tr>
<tr>
<td>Nomor Telephon</td>
<td>:</td>
<td>+6281993474995</td>
</tr>
<tr>
<td>E-mail</td>
<td>:</td>
<td><a href="jumiatyrahmi@gmail.com" style="text-decoration: none;color: black";>jumiatyrahmi@gmail.com</a></td>
</tr>
<tr>
<td>Hobi</td>
<td>:</td>
<td>Coding, Traveling,Nonton Anime</td>
</tr>
<td colspan="3" align="right">
<a href="Tugas.html" style="text-decoration: none;"</a><input type="button" onclick="history.back()" value="Menu"/>
<a href="index.php" style="text-decoration: none;"</a><input type="button" onclick="history.back()" value="Menu Maskapai"/>
<a href="Biodata.php" style="text-decoration: none;"</a><input type="button" onclick="history.back()" value="Kembali"/>
</td>
</table>
</form>
</body>
</html>